import json
import boto3
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth


def get_sqs():
    sqs = boto3.client('sqs')
    url = 'https://sqs.us-east-1.amazonaws.com/537502574872/dining-concierge-requests'

    res = sqs.receive_message(
        QueueUrl=url,
        AttributeNames=['SentTimestamp'],
        MessageAttributeNames=['All'],
        MaxNumberOfMessages=10
    )
    
    messages = []
    if 'Messages' in res:
        for m in res['Messages']:
            messages.append({key: val['MessageAttributes'][key]['StringValue'] for key, val in m})
            sqs.delete_message(m['ReceiptHandle'])
    
    return messages

def query_opensearch(cuisine):
    REGION = 'us-east-1'
    HOST = 'search-yelp-restaurants-dining-uqjdd4t2jfqmkcjsesapxiy7aa.us-east-1.es.amazonaws.com'
    INDEX = 'restaurants'
    q = {'size': 5, 'query': {'multi_match': {'query': cuisine}}}

    client = OpenSearch(hosts=[{
        'host': HOST,
        'port': 443
    }],
                        http_auth=get_awsauth(REGION, 'es'),
                        use_ssl=True,
                        verify_certs=True,
                        connection_class=RequestsHttpConnection)
    res = client.search(index=INDEX, body=q)
    print(res)
    hits = res['hits']['hits']
    results = []
    for hit in hits:
        results.append(hit['_source'])
    restaurant_ids = [result['id'] for result in json.loads(results['body'])['results']]
    
    return restaurant_ids

def get_awsauth(region, service):
    cred = boto3.Session().get_credentials()
    return AWS4Auth(cred.access_key,
                    cred.secret_key,
                    region,
                    service,
                    session_token=cred.token)

def lambda_handler(event, context):
    results = query_opensearch('chinese')
    return {
        'statusCode': 200,
        'headers': {
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({'results': results})
    }
